# dio-desafio-solucoesSDK
Desafio de criação de Soluções Robustas no Dynamics 365 com a Extensão SDK para o Bootcamp Microsoft Dynamics 365 da DIO
